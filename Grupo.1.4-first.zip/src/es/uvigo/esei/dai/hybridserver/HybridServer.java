package es.uvigo.esei.dai.hybridserver;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Map;
import java.util.Properties;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;



public class HybridServer {
	private int SERVICE_PORT = 8888;
	private String dburl;
	private String dbuser;
	private String dbpassword;
	private Thread serverThread;
	private boolean stop;
	private HtmlController dao;
	private int numClients = 50;


	public HybridServer() {
		// TODO Auto-generated constructor stub
		this.dburl = "jdbc:mysql://localhost:3306/hstestdb";
		this.dbuser = "hsdb";
		this.dbpassword = "hsdbpass";
		this.dao = new HtmlController(new HtmlDBDAO(this.dburl,this.dbuser,this.dbpassword));
	}

	public HybridServer(Map<String, String> pages) {
		// TODO Auto-generated constructor stub
		this.dao = new HtmlController(new HtmlMapDAO(pages));
	}

	public HybridServer(Properties properties) {
		// TODO Auto-generated constructor stub
		this.numClients = Integer.parseInt(properties.getProperty("numClients"));
		this.SERVICE_PORT = Integer.parseInt(properties.getProperty("port"));
		this.dburl = properties.getProperty("db.url");
		this.dbuser = properties.getProperty("db.user");
		this.dbpassword = properties.getProperty("db.password");
		
		this.dao = new HtmlController(new HtmlDBDAO(this.dburl,this.dbuser,this.dbpassword));
	}

	public int getPort() {
		return SERVICE_PORT;
	}

	public void start() {
		this.serverThread = new Thread() {
		ExecutorService exec = Executors.newFixedThreadPool(numClients);	

			@Override
			public void run() {
				Socket socket = null;
				try (ServerSocket serverSocket = new ServerSocket(SERVICE_PORT)) {
					while(true) {
					   try {
						   	socket= serverSocket.accept();
						   	if(stop) 
						   		break;
				         } catch (IOException e) {
				             throw new RuntimeException(
				                "Error accepting client connection", e);
				         }
					   exec.execute(new HybridService(socket, dao));
					}
					
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		};

		this.stop = false;
		this.serverThread.start();
	}

	public void stop() {
		this.stop = true;

		try (Socket socket = new Socket("localhost", SERVICE_PORT)) {
			// Esta conexión se hace, simplemente, para "despertar" el hilo servidor
		} catch (IOException e) {
			throw new RuntimeException(e);
		}

		try {
			this.serverThread.join();
		} catch (InterruptedException e) {
			throw new RuntimeException(e);
		}

		this.serverThread = null;
	}
}
