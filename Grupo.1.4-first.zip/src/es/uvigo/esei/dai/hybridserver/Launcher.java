package es.uvigo.esei.dai.hybridserver;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.Properties;

public class Launcher {
	public static void main(String[] args) {

		HybridServer h = null;
		if (args.length == 1) {

			FileReader fr = null;
			Properties p = new Properties();
			
			try {
				
				fr = new FileReader(args[0]);

				BufferedReader bf = new BufferedReader(fr);
				String line = "";

				while ((line = bf.readLine()) != null) {
					String[] propert = line.split("=");
					p.put(propert[0], propert[1]);
				}
				bf.close();
				h = new HybridServer(p);
				h.start();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		} else if(args.length == 0){
			 h = new HybridServer();

			h.start();
		}else {
			System.out.println("Error: Hay más de un parámetro para inicializar el HybridServer");
		}

	}
}
