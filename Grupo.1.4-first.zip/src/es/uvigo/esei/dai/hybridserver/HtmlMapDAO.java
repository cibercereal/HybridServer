package es.uvigo.esei.dai.hybridserver;

import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

public class HtmlMapDAO implements HtmlDAO{
	
	private Map<String, String> pags;
	
	public HtmlMapDAO(Map<String, String> pages) {
		this.pags = new HashMap<String, String>(pages);
	}
	
	public String getContentPage(String uuid) {
		return pags.get(uuid);
	}
	
	public List<String> getList() {
		List<String> list = new LinkedList<>();
		for (String string : this.pags.keySet()) {
			list.add("<p><a href=\"html?uuid=" + string + "\">" 
					+ string + "</a></p>");
		}
		return list;
	}
	
	public void putPages(String uuid,String content) {
		pags.put(uuid, content);
	}
	
	public void removePages(String uuid) {
		pags.remove(uuid);
	}
	
	public boolean containsPage(String uuid) {		
		return pags.containsKey(uuid);
	}
}
