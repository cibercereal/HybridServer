package es.uvigo.esei.dai.hybridserver;

import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.Socket;
import java.util.List;
import java.util.UUID;

import es.uvigo.esei.dai.hybridserver.http.HTTPParseException;
import es.uvigo.esei.dai.hybridserver.http.HTTPRequest;
import es.uvigo.esei.dai.hybridserver.http.HTTPRequestMethod;
import es.uvigo.esei.dai.hybridserver.http.HTTPResponse;
import es.uvigo.esei.dai.hybridserver.http.HTTPResponseStatus;

public class HybridService implements Runnable {

	private Socket socket;
	private HtmlController pages;

	public HybridService(Socket s, HtmlController pages) {
		// TODO Auto-generated constructor stub
		socket = s;
		this.pages = pages;
	}

	@Override
	public void run() {
		try (Socket socket = this.socket) {
			
			//Recibir request
			HTTPRequest req = new HTTPRequest(new InputStreamReader(socket.getInputStream()));
			System.out.println("READ");
			HTTPRequestMethod method = req.getMethod();
			String[] resourcesPath = req.getResourcePath();
			String resource = "";
			if (resourcesPath.length > 0) // si hay recursos cogemos el ultimo
				resource = resourcesPath[resourcesPath.length - 1].trim();
			
			//Crear response
			HTTPResponse res = new HTTPResponse();
			res.setVersion(req.getHttpVersion());
			
			OutputStreamWriter output = new OutputStreamWriter(socket.getOutputStream());

			
			String content = "";
			String uuid = "";
			
			switch (method) {
			
			case GET:
				
				try {
					if (req.getResourceChain().contains("uuid") && req.getResourceName().equals("html")) {
						
						//Obtener uuid del Request
						uuid = req.getResourceParameters().get("uuid");
						
						if (pages.containsPage(uuid) && (content = pages.getContentPage(uuid)) != null) {
							//devolver contenido correspondiente al uuid
							res.setStatus(HTTPResponseStatus.S200);
							res.setContent(content);

						} else {
							
							res.setStatus(HTTPResponseStatus.S404);
							
						}
						
					} else if (resource.equals("")) {
						//devolver pagina de bienvenidad
						res.setStatus(HTTPResponseStatus.S200);
						res.setContent("Hybrid Server");
						
					} else if (!req.getResourceName().equals("html")) {
						
						res.setStatus(HTTPResponseStatus.S400);
						
					} else {
						
						res.setStatus(HTTPResponseStatus.S200);
						res.setContent(transformList(pages.getList()));
						
					}
					
				} catch (RuntimeException e) {
					
					res.setStatus(HTTPResponseStatus.S500);
					
				}
				
				res.putParameter("Content-Length", Integer.toString(res.getContent().length()));
				//Responde al cliente
				
				res.print(output);
				
				break;
				
			case POST:
				try {
					if (req.getResourceName().equals("html")
							&& (content = req.getResourceParameters().get("html")) != null) {
						
						//Crear nuevo uuid
						UUID randomUuid = UUID.randomUUID();
						uuid = randomUuid.toString();
						
						String link = "<a href=\"html?uuid=" + uuid + "\">" + uuid + "</a>";
						// Introducir nueva pagina en la base de datos o Map
						pages.putPages(uuid, content);
						
						res.setStatus(HTTPResponseStatus.S200);
						res.setContent(link);

					} else {
						
						res.setStatus(HTTPResponseStatus.S400);
						
					}
				} catch (RuntimeException e) {
					
					res.setStatus(HTTPResponseStatus.S500);
					
				}
				
				res.putParameter("Content-Length", Integer.toString(res.getContent().length()));
				
				res.print(output);
				
				break;
				
			case DELETE:
				
				try {
					
					if (req.getResourceChain().contains("uuid")) {
						
						uuid = req.getResourceParameters().get("uuid");
						
						if (pages.containsPage(uuid)) {
							
							pages.removePages(uuid);
							res.setStatus(HTTPResponseStatus.S200);
							
						} else {
							
							res.setStatus(HTTPResponseStatus.S404);
							
						}

					} else {
						
						throw new HTTPParseException();
						
					}
					
				} catch (RuntimeException e) {
					
					res.setStatus(HTTPResponseStatus.S500);
					
				}
				
				res.putParameter("Content-Length", Integer.toString(res.getContent().length()));
				res.print(output);
				
				break;
				
			default:
				break;
			}

		} catch (HTTPParseException | IOException e) {
			e.printStackTrace();
		}
	}

	public String transformList(List<String> list) {
		String toRet = "";
		for (String string : list) {
			toRet += string + "\n";
		}
		return toRet;
	}

}
