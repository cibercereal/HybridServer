package es.uvigo.esei.dai.hybridserver;

import java.util.List;

public class HtmlController {
	private HtmlDAO dao;

	public HtmlController(HtmlDAO dao) {
		this.dao = dao;
	}
	
	public String getContentPage(String uuid) {
		return dao.getContentPage(uuid);
	}

	public List<String> getList() {
		return dao.getList();
	}

	public void putPages(String uuid, String content) {
		dao.putPages(uuid, content);
	}

	public void removePages(String uuid) {
		dao.removePages(uuid);
	}

	public boolean containsPage(String uuid) {
		return dao.containsPage(uuid);
	}
	
}
